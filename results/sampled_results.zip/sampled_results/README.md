This directory contains the results regarding samples of the execution of the Non-VR projects.


Characteristics


| Atribute                          | Non-VR    |
|-----------------------------------|-----------|
| Projects                          | 107       |
| Number of classes                 | 4186      |
| Number of lines of code (C# Only) | 712899    |