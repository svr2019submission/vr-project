This directory contains the results regarding the execution of the experiment for all classes of VR and Non-VR projects

Characteristics

| Atribute                          |     VR    | Non-VR    |
|-----------------------------------|:---------:|-----------|
| Projects                          | 119       | 107       |
| Number of classes                 | 21,508    | 21,563    |
| Number of lines of code (C# Only) | 2,314,522 | 2,455,766 |